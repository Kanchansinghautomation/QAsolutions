package com.homepage.testing;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Healthplanhomepage {	
			
		      WebDriver ldriver;
		      		      
		      public Healthplanhomepage(WebDriver rdriver )
		      
		       {
		    	  ldriver=rdriver;
		    	  PageFactory.initElements(rdriver, this);		    	  
		       }
		    	  
		      @FindBy(id="health-city")		      
		      @CacheLookup		      
		      WebElement  cityname;
              
		      @FindBy(id="health_name")		      
		      @CacheLookup		      
		      WebElement  Name;
		      
		      
		     // @FindBy(xpath="//span[.='28 Years']")      
		    //  @CacheLookup		      
		   //   WebElement  Age;
		     
		      
		      @FindBy(id="health-mobile")		      
		      @CacheLookup		      
		      WebElement  Mbilenumber;
		      
		      @FindBy(xpath=("/html/body/div[3]/div/section/div/div[2]/div[2]/div/form/div[3]/div/button"))	      
		      @CacheLookup		      
		      WebElement  btnsubmit;
		      
		      @FindBy(className="close()")
		      @CacheLookup
		      WebElement closedpopup;
		      

		    
		      public void setcity(String city ) {
		    	  
		    	  cityname.sendKeys("city",Keys.DOWN);
		    	  
		      }
		      
		      
            public void  setname(String name ) {
		    	  
        	 Name.sendKeys(name);
		    	  
        }
         
      //  public void  setage(String age ) {
       
        	//age.sendKeys("age", Keys.DOWN);
		    	  
    //  }
         
         public void  setmobilenumber(String mobile ) {
	    	  
        	 Mbilenumber.sendKeys(mobile);
        	 
		    	  
       }
         public void  clicksubmit() {
	    	  
        	 btnsubmit.click();
        	 
		    	  
       }
         
         
         
		      
	}
		

	
	

