package com.kanchan.Automationtesting;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.homepage.testing.Healthplanhomepage;
public class Testcase extends BaseTest {	
	
@Test

public void logintest() {
	
		driver.get(baseurl);
		
		logger.info("open the url");
		
		Healthplanhomepage hp=new Healthplanhomepage(driver);
		
		hp.setcity(city);
		 
		logger.info("enter city name");
		
		hp.setname(Name);
		
		//hp.setage(age);	
		
		hp.setmobilenumber(mobilenumber);
		
		hp.clicksubmit();
		
		Assert.assertEquals("ComparePolicy", driver.getTitle());

	}
  }


