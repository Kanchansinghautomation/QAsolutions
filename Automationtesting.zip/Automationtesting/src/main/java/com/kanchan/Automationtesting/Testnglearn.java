package com.kanchan.Automationtesting;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Testnglearn {	
	
@BeforeClass	
	void mainclass() {		
	System.out.println("-------Before class------");	
}
@AfterMethod
 void aftermethod(){		
 System.out.println("---------After Method-------");		
}

@Test 
void Testone() {	
System.out.println("---------Test Method one------");
}

@BeforeMethod
void beforemethod() {	
System.out.println("--------------Before Method");
  }

@Test
void Testtwo() {		
System.out.println("------------Test Method Two");
}

@BeforeSuite
void suite() {	
System.out.print("-------------Before suite-------");	
}
@BeforeTest
void beforetest() {
System.out.print("---------------Before test--------");
}	
}

