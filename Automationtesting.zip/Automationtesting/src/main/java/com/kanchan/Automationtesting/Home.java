package com.kanchan.Automationtesting;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class Home {
	
	public static void main(String[] args) {
	// TODO Auto-generated method stub

        System.setProperty("webdriver.chrome.driver","chromeexefile//chromedriver.exe"); 
		  
    	  WebDriver driver=new ChromeDriver();
		  
		  driver.get("https://www.comparepolicy.com/#health");
		  
		  driver.findElement(By.id("health-city")).sendKeys("agra" ,Keys.DOWN);
	
		  driver.findElement(By.id("health_name")).sendKeys("testing");
		  
		  
		  driver.findElement(By.id("health-mobile")).sendKeys("9999999999");
		  
		  
		  driver.findElement(By.xpath("/html/body/div[3]/div/section/div/div[2]/div[2]/div/form/div[3]/div/button")).click();
		  
		  driver.findElement(By.xpath("//*[@class='close'])")).click();
		  
			}

}
