package com.kanchan.Automationtesting;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class BaseTest {	
	public String baseurl="https://www.comparepolicy.com/#health";
	public String city="Agra";
	public String Name="Testing";
	public String age="28 years";
	public String mobilenumber="9999999999";
	
	//public String closedpopup;
	
	public static WebDriver driver;	
	
    public static Logger logger;


@BeforeClass

 public void setup() {
	 
	  System.setProperty("webdriver.chrome.driver","chromeexefile//chromedriverk.exe");
	  
	  driver=new ChromeDriver();
	  
	  logger=Logger.getLogger("homeinsuranceproject");
	  
	  PropertyConfigurator.configure("log4j.proparties");
	  
}

@AfterClass

	 public void closed() {
	
	 driver.manage().window().maximize();
	 
	// driver.quit();

     }
}
	  

   


